async function generate() {
  const prompt = document.getElementById("prompt").value;
  const style = document.getElementById("style").value;
  const mode = document.getElementById("mode").value;
  const output = document.getElementById("output");

  if (!prompt || !mode) {
    alert("Please enter a prompt and select a mode.");
    return;
  }

  const styledPrompt = style ? `${style} style, ${prompt}` : prompt;

  output.innerHTML = "<p>Generating " + mode + "...</p>";

  try {
    const res = await fetch("https://your-api-url.com/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt: styledPrompt, mode }),
    });

    const data = await res.json();

    if (data.url) {
      const mediaTag = mode === "image"
        ? `<img src="${data.url}" alt="Generated Image">`
        : `<video src="${data.url}" controls autoplay loop muted></video>`;

      const downloadBtn = `<a href="${data.url}" download class="download-btn">Download</a>`;
      const copyBtn = `<button class="copy-btn" onclick="navigator.clipboard.writeText('${data.url}')">Copy Link</button>`;

      output.innerHTML = mediaTag + "<br>" + downloadBtn + copyBtn;
    } else {
      output.innerHTML = `<p>Error: ${data.error}</p>`;
    }
  } catch (err) {
    output.innerHTML = `<p>Server Error: ${err.message}</p>`;
  }
}
